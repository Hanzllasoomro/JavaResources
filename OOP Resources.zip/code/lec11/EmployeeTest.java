
public class EmployeeTest {
	
    public static void main(String[] args) {
		Address postalAddress = new Address("House No. 45, Block A", "PCSIR Society", "Lahore");
		
		Employee emp1 = new Employee(1, "Abid", postalAddress);
		emp1.display();
		
		System.out.println(emp1.getPostalAddress().city);
		test(emp1);		
	}	
	
	public static void test(Employee emp){
		emp.getPostalAddress().town = "Model Town";
		System.out.println(emp.getPostalAddress().town);		
	}
}