public class Address{
	
	String streetAddress;
	String town;
	String city;
	
	public Address(String streetAddress, String town, String city){
		this.streetAddress = streetAddress;
		this.town = town;
		this.city = city;		
	}
	
	// make 3 fields private
	// define get and set method for each field
	// I skipped to keep it simple / focussed.
	
}