public class BankAccount{
	
    private double balance;
    private String name;
	private int depositsCount;
	private int withdrawsCount;
	
	public BankAccount(double balance, String name){
		if(balance > 0)
			this.balance = balance;		
		this.name = name;
	}
	
    void deposit(double amount){
		if(balance >= 100000)
			amount = (amount) + ((amount) * (1/100.0));
        balance += amount;      
		depositsCount++;
    }
	
    void withdraw(double amount){
		if(balance < 50000)
			amount = (amount) + ((amount)*(2.0/100.0));
        balance -= amount;    
		withdrawsCount++;
    }
	
	public int getDepositsCount(){
		return depositsCount	
	}
	
	public int getWithdrawsCount(){
		return withdrawsCount;
	}
	
	public double getBalance(){
		return balance;
	}
	
	public String getName(){
		return name;
	}
}