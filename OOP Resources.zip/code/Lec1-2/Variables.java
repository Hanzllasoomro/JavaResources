public class Variables {
	
	public static void main(String[] args){
		
		int num = 20; // literal
		byte num2 = 10;
		short num3 = 450;		
		char status = 'a';
		long num4 = 12345678912345L;
		
		double num5 = 45.70;
		float num6 = 45.70F;

		boolean flag = false;
		
		System.out.println(" Message 1\" \nMessage 2");
		
		
	}
	
	
}