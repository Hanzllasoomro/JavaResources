public class Student {
	private int id;
	String name;
	double marks1;
	double marks2;
	private String mobileNumber;
		
	public void setId(int id){
		
		if(id > 0)
			this.id = id;
		else
			System.out.println("Invalid id passed.");
	}
	
	public int getId(){
		return id;
	}
		
	private double calculateAverage(){
		double sum = marks1 + marks2;
		return sum / 2.0;
	}
/*
	public boolean isPass(){
		if(calculateAverage() >= 50)
			return true;
		else return false;
	}
	
	public void test(){
		System.out.println(mobileNumber);
	}
		*/

}