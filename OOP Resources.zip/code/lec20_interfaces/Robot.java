package com.bitspedia.oop.lec20_interfaces;

public class Robot extends Machine implements Walkable{

    @Override
    public void walk() {
        System.out.println("Logic of walk for robot .... ");
    }
}
