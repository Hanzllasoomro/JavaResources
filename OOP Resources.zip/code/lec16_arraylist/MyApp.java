package com.bitspedia.oop.lec16_arraylist;

import java.util.Arrays;

// This class demo if we do no use ArrayList, how we have to use
// arrays to add any number of elements, only a glimpse.

public class MyApp {

    static String[] names;
    static int lastUsedIndex = -1;

    public static void main(String[] args) {
        int initialCapacity = 2;

        names = new String[initialCapacity];
        add("Ali");
        add("Shahzad");
        add("Abid");
        add("Abid");
        add("Abid");


        for(String name: Arrays.copyOf(names, lastUsedIndex + 1)) {
            System.out.println(name);
        }
        System.out.println(names.length);
    }

    static void add(String name){
        if(lastUsedIndex == names.length - 1){
            String[] temp = new String[names.length * 2];
            for (int i = 0; i < names.length; i++) {
                temp[i] = names[i];
            }
            names = temp;
        }
        names[++lastUsedIndex] = name;
    }


}
