package com.bitspedia.oop.lec18_inheritance;

public class StdTest {
    public static void main(String[] args) {
        Student std = new Student(1, "Ali", "OOP");
        System.out.println(std.getId());
    }
}
