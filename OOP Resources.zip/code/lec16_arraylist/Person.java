package com.bitspedia.oop.lec16_arraylist;

// instance variable
// static variable
// local variable

public class Person {
    static int counter;
    public final int id;
    static final String country;

    static{
        country = "Pakistan";
    }

    {
        id = ++counter;
    }

    public Person() {

    }

    public static void main(String[] args) {
        Person person = new Person();
    }

    void printData(final String cnic){
        final int id;
        id = 20;

        System.out.println(cnic);
    }
}
