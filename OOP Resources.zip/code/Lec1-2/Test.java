import java.util.Scanner;

public class Test {
	
 public static void main(String [] args) {
	 int num = 3256345;	 
	 System.out.println(num);	 
	 while(num>10){
		int remainder = num % 10;
	    System.out.println(remainder);
		num = num / 10;
	 }
 	 System.out.println(num);
 }
 

 

 }