package com.bitspedia.oop.lec20_interfaces;

public interface Walkable {

    void walk();

}
