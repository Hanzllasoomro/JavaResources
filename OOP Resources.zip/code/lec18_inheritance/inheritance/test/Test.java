    package com.bitspedia.oop.lec18_inheritance.inheritance.test;

    public class Test {

        public static void main(String[] args) {



        }
    }
