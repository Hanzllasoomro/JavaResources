package com.bitspedia.oop.lec17_enum;

public enum GameStatus {
    WON, LOST, DRAW
}
