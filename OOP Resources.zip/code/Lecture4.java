import java.util.Scanner;

public class Lecture4 {
	
	public static void main(String args[]){
		
		int num = 10;
		// boolean evenNumber = isEven(num);
		if(num > 0) {
			System.out.println("Number is positive");
		} else if(num < 0) {
			System.out.println("Number is negative");
		} else {
			System.out.println("Number is zero.");
		}
		/*
		int i=1;
		do{
			System.out.println(i);						
			i++;
		}while( i<=10);		
		*/
		
	}
	
	public static boolean isEven(int number){
			if(number % 2 == 0 )
				return true;
			else
				return false;
	}
	
}