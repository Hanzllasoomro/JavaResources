package com.bitspedia.lms;

public class Book{
	
	public String isbn;	
	
}