package com.bitspedia.oop.lec19_abstraction.example1;

public class Test {

    public static void main(String[] args) {

        Shape shape = new Rectangle(2,3);

        // what methods we can call from 'shape' reference is decided by the type of the reference
        // variable. its not decided by the object to which the variable points

        shape.calculateArea();

        // when we can use type casting, then why we define/declare the method in parent class

    }
}
