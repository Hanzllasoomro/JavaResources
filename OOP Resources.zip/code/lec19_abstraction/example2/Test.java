package com.bitspedia.oop.lec19_abstraction.example2;

public class Test {
    public static void main(String[] args) {

        CommissionEmployee commissionEmployee = new CommissionEmployee(1, "Ali",
                0.03, 300000);
        commissionEmployee.setBankAccountNumber(10);

        HourlyEmployee hourlyEmployee = new HourlyEmployee(2,"Abid", 160, 10);
        hourlyEmployee.setBankAccountNumber(20);

        PieceWorker pieceWorker = new PieceWorker(1000, 100);
        pieceWorker.setBankAccountNumber(30);

        Accounts accounts = new Accounts();
        accounts.depositEarningsIntoAccount(commissionEmployee);
        accounts.depositEarningsIntoAccount(hourlyEmployee);
        accounts.depositEarningsIntoAccount(pieceWorker);

    }
}
