package com.bitspedia.oop.lec18_inheritance.inheritance2;

public class Product {
}
