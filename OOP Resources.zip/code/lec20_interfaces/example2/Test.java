package com.bitspedia.oop.lec20_interfaces.example2;

import java.util.ArrayList;

public class Test {

    public static void main(String[] args) {

        Employee employee = new Employee();
        Invoice invoice = new Invoice(10, 200 );
        ArrayList<Payable> payables = new ArrayList<>();
        payables.add(employee);
        payables.add(invoice);
        sumPayments(payables);
    }

    static void sumPayments(ArrayList<Payable> payableArrayList){
        double sum = 0;
        for(Payable payable1 : payableArrayList){
            sum+=payable1.getPaymentAmount();
        }
        System.out.println( " Total Payment Amount : " + sum);

    }

}
