package com.bitspedia.sms.app;

import com.bitspedia.sms.*;
import com.bitspedia.lms.Book;

public class StudentTest{
	
	public static void main(String[] args){		
		Student s = new Student(1);
		System.out.println(s.id);
		
		Book book = new Book();
		book.isbn = "234234-24-234234";
		System.out.println(book.isbn);
		
	}	
}