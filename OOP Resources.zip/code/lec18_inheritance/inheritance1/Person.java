package com.bitspedia.oop.lec18_inheritance.inheritance1;

public class Person {
    public int id;

    public Person(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    protected void m1(){
        System.out.println("m1 called ");
    }
}