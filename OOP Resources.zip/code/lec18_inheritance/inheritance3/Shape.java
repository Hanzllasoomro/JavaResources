package com.bitspedia.oop.lec18_inheritance.inheritance3;

public class Shape extends Object {
    private int id;

    public Shape(int id) {
        this.id = id;
    }

    public Shape() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double calculateArea(){
        System.out.println("Shape.calculateArea called. ");
        return 0;
    }

    @Override
    public String toString(){
        return "Shape {id = " + getId() + " } ";
    }

}
