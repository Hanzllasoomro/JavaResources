package com.bitspedia.oop.lec18_inheritance.inheritance3;

public class Square extends Rectangle {
    private double size;

    public Square(double size) {
        super(size, size);
        this.size = size;
    }

    public double getSize() {
        return size;
    }

    public void setSize(double size) {
        this.size = size;
    }
}
