public class TestApp {

	public static void main(String args[]){
		Student s1 = new Student();
		int n = -10;
		
		if(n>10)
	       s1.id = n;
		
		s1.setId(10);
		
		System.out.println(s1.getId());
		

	}
}