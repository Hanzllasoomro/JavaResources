package com.bitspedia.oop.lec18_inheritance.test;

import com.bitspedia.oop.lec18_inheritance.Student;

public class StudentTest {

    public static void main(String[] args) {
        Student student = new Student(1, "ali", "OOP");
        System.out.println(student.getCourseName());
        System.out.println(student.getName());
    }
}
