import java.util.Scanner;

public class DataInput{
	// small / capital ... 
	// how to know the list of methods available on a ref type

	public static boolean isPrime(int num){		
		boolean isPrime = true;
		for(int i=2; i <= (num-1); i++){
			if(num % i == 0){
				isPrime = false;
				break;
			}
		}
		return isPrime;
	}
		
	public static void main(String[] args){		
		Scanner input = new Scanner(System.in);
		
		System.out.println("Enter upper limit > ");				
		int num = input.nextInt();		
		int primeCounter = 0;
		
		for(int i=1; i<=num; i++){
			if(isPrime(i)){
				primeCounter++;
				System.out.println("Prime found " + i);
			}
		}
		
		//System.out.println("sum = " + num);	
		//Scanner input = new Scanner(System.in);
		//System.out.println("Enter a number > ");		
		//int num = input.nextInt();
		//System.out.printf("%d X %d = %d\n", num, i, (num*i));
		
//		for(int i=1; i<=10; i++)
	//		System.out.println(num + " X " + i + " = " + (num*i));
		
		
		/*
		if(num % 2 == 0)
			System.out.println("number is even");
		else 
			System.out.println("number is odd");
		*/
		
//		int sum = 10;
		/*
		System.out.print("A");
		System.out.println("B");
		System.out.print("C");
		System.out.printf("Value of sum is %d\n\n", sum);
		System.out.print("D"); */		
	}	
	

}