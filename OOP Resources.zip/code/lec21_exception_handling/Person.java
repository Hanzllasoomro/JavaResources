package com.bitspedia.oop.lec21_exception_handling;

import java.util.Scanner;

public class Person {
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        if(id <= 0) {
            System.out.println("Invalid ID");
            throw new IllegalArgumentException();
        }
        this.id = id;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Person person = new Person();
        while(true) {
            try {
                System.out.println("Input valid ID .. ");
                int id = scanner.nextInt();
                person.setId(id);
                break;
            } catch (IllegalArgumentException exp) {
                System.out.println(exp.getMessage());
            }
        }
        System.out.println("ID = " + person.getId());
    }
}
