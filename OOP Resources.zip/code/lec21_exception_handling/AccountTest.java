package com.bitspedia.oop.lec21_exception_handling;

public class AccountTest {

    public static void main(String[] args) {

        Account account = new Account(1, "Asif Shahzad", 1000);
        try {
            account.withdraw(2000);

        }catch(InvalidAmountException exp) {
            System.out.println(exp.getMessage());

        }catch(InsufficientBalanceException exp){
            System.out.println(exp.getMessage());
            System.out.println(exp.getAccountId());
        }

        System.out.println(account.getBalance());
    }
}
