package com.bitspedia.sms;

public class Student{
	
	public int id;
	
	public Student(int id){
		this.id = id;
	}	
}