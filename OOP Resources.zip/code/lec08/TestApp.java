public class TestApp {

	public static void main(String args[]){
		
		Person p = new Person(10);		
		Person p2 = new Person(20, "Asif Shahzad");
	
		Person p3 = new Person();		
		
		System.out.println(p2.getId());
		System.out.println(p2.getName());
		
		System.out.println(p2.sum(4, 8));
		
	}
}