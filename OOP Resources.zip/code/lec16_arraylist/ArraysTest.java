package com.bitspedia.oop.lec16_arraylist;

import java.util.Arrays;

public class ArraysTest {

    public static void main(String[] args) {
        int nums[] = new int[]{5, 7, 1, 8, 4, 12};
        String names[] = new String[]{"Zahid", "Abid", "Kashif", "Bilal"};

        Arrays.sort(names);

        for (String n : names) System.out.println(n);


    }
}
