package com.bitspedia.oop.lec19_polymorphism.example1;

public class Shape {

    public double calculateArea() {
        System.out.println("Shape.calculateArea called. ");
        return 0;
    }
}
