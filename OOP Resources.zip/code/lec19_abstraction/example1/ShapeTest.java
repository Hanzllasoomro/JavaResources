package com.bitspedia.oop.lec19_abstraction.example1;

public class ShapeTest {

    public static void main(String[] args) {

        Shape shape = new Circle(10);

        Rectangle rectangle1 = new Rectangle(2,3);
        Circle circle = new Circle(5);
        Square square = new Square(3);
        Triangle triangle = new Triangle(4,5);

        Painter painter = new Painter();

        double cost1 = painter.estimatePaintingCost(rectangle1);
        double cost2 = painter.estimatePaintingCost(circle);
        double cost3 = painter.estimatePaintingCost(square);
        double cost4 = painter.estimatePaintingCost(triangle);

        System.out.println(cost1);
        System.out.println(cost2);
        System.out.println(cost3);
    }
}
