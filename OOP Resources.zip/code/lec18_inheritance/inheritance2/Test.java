package com.bitspedia.oop.lec18_inheritance.inheritance2;

public class Test {
    public static void main(String[] args) {

//        BasePlusCommissionEmployee employee = new BasePlusCommissionEmployee(
//                1, "Shahzad", 0.03, 300000, 50000);
//        System.out.println(employee.getEarnings());
//        System.out.println(employee);

        BasePlusCommissionEmployee employee = new BasePlusCommissionEmployee(1,"Ali",
                0.03,300000, 454454);
        System.out.println(employee.getEarnings());
    }
}
