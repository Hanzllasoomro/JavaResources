package com.bitspedia.oop.lec18_inheritance.inheritance3;

public class ShapeTest {

    public static void main(String[] args) {

        Rectangle rectangle = new Rectangle(1,2,3);
        System.out.println(rectangle);

    }

    public static void printInfo(Shape... shapes) {
        int rectanglesCounter = 0;
        int circlesCounter = 0;

        for (Shape shape : shapes) {

            if (shape instanceof Rectangle) {
                Rectangle r = (Rectangle)shape;
                System.out.println("Length = " + r.getLength());

                rectanglesCounter++;
            } else if (shape instanceof Circle) {
                Circle c = (Circle)shape;
                System.out.println("Radius = " + c.getRadius());
                circlesCounter++;
            }
        }
        System.out.println("Circles = " + circlesCounter);
        System.out.println("Rectangles = " + rectanglesCounter);

    }


}
