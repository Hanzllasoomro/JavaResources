package com.bitspedia.oop.lec21_exception_handling;

public class InsufficientBalanceException extends Exception {

    private int accountId;

    public InsufficientBalanceException(int accountId) {
        this.accountId = accountId;
    }

    public InsufficientBalanceException(String message, int accountId) {
        super(message);
        this.accountId = accountId;
    }

    public int getAccountId() {
        return accountId;
    }
}
