public class Student {
    private int id;
    private String name;
	static String university = "COMSATS";	
	static int counter;	
	
    public Student(String name) {
		System.out.println("constructor called ... ");
        this.id = ++counter;
        this.name = name;		
    }
	
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void display(){
        System.out.println(id);
        System.out.println(name);
		
		System.out.println(university);
		printCounter();
    }
	
	static void testStatic(){
		System.out.println("testStatic method ... " + university);
		printCounter();
	}
	
	static void printCounter(){
		System.out.println("Counter = " + counter);
	}
	
	
	
}
