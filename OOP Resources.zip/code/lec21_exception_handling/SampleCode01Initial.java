package com.bitspedia.oop.lec21_exception_handling;

import java.util.InputMismatchException;
import java.util.Scanner;

public class SampleCode01Initial {

    public static void main(String args[]) {
        System.out.println("First statement.");

        Scanner scanner = new Scanner(System.in);
        int numbers[] = new int[]{1, 2, 7, 8};

        System.out.println("Enter value of index: ");
        int index = scanner.nextInt();

        System.out.println(numbers[index]);

        System.out.println("abc");
        System.out.println("xyz");

        System.out.println("Last statement.");
    }
}