package com.bitspedia.oop.lec18_inheritance;

public class Person {
    private int id;
    private String name;

    public Person(int id, String name) {
       this.id = id;
       setName(name);
    }

    protected int getId() {
        return id;
    }

    protected void setId(int id) {
        if(id > 0 )
            this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void m1(){
        System.out.println("m1 called in person class");
    }

}
