package com.bitspedia.oop.lec20_interfaces.example2;

public class Invoice implements Payable{
    double qty;
    double unitPrice;

    public Invoice(double qty, double unitPrice) {
        this.qty = qty;
        this.unitPrice = unitPrice;
    }

    @Override
    public double getPaymentAmount() {
        return qty * unitPrice;
    }
}
