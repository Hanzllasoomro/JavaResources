package com.bitspedia.oop.lec20_interfaces.example2;

import com.bitspedia.oop.lec20_interfaces.Walkable;

public class Employee implements Payable, Walkable {

    double salary = 1000;

    @Override
    public double getPaymentAmount() {
        return salary;
    }

    @Override
    public void walk() {

    }
}
