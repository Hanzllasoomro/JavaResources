package com.bitspedia.oop.lec20_interfaces;

import java.util.ArrayList;

public class Test {

    public static void main(String[] args) {
        Walkable walkable = new Human();

        ArrayList<Walkable> walkableArrayList = new ArrayList<>();
        walkableArrayList.add(walkable);
        walkableArrayList.add(new Robot());
        walkableArrayList.add(new Human());

        proceedWalking(walkableArrayList);
    }

    static void proceedWalking(ArrayList<Walkable> walkableArrayList){
        for (Walkable walkable : walkableArrayList ) {
            walkable.walk();
        }

    }

}
