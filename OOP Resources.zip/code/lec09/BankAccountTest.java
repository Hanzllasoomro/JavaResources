import java.util.Scanner;

public class BankAccountTest{
	
    public static void main(String[] args){
        
        Scanner input = new Scanner(System.in);        	
        System.out.println("Enter account name >");
        String accountname = input.nextLine(); 
		
        System.out.println("Enter the balance in your account > ");
        double initialbalance = input.nextDouble();		
		
		BankAccount bankAccount = new BankAccount(initialbalance, name);	        
		int menuOption = 0;
		
        do {           
			System.out.println("Press 1: To Deposit an amount");
			System.out.println("Press 2: To Withdraw an amount");
			System.out.println("Press 3: To View the current balance");
			System.out.println("Press 4: To Close this program");			
			menuOption = input.nextInt();
			
			switch(menuOption){
				case 1:						
					bankAccount.deposit(getAmount());					
					break;
					
				case 2:			
					if(bankAccount.balance < 50000){
				   		System.out.println(
						"As you sure you want to withdraw, it would make your " + 
						"balance below 50,000. Press 1 to continue and 0 to abort");
						
						if(input.nextInt() == 0 ) continue;
					}	
					bankAccount.withdraw(getAmount());					
					break;
					
				case 3:
					System.out.println("Your balance is =" + bankAccount.balance);
					break;
			}
        } while( menuOption != 4);
       
        System.out.println("Account Title:" + bankAccount.getName());
        System.out.println("Total deposits:" + bankAccount.getDepositsCount());
        System.out.println("Total withdraws:" + bankAccount.getWithdrawsCount());
        System.out.println("Balance:" + bankAccount.getBalance());
    }
	
	public static double getAmount(){
		Scanner input = new Scanner(System.in);		
		System.out.println("Enter the amount > ");
		double amount = input.nextDouble();
		return amount;	
	}
}