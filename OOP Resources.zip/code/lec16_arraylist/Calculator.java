package com.bitspedia.oop.lec16_arraylist;

public class Calculator {

    public static void main(String[] args) {
        printData("Abid", "Zahid", "Zia");
    }

    static void printData(String... names){
        for(String name: names) {
            System.out.println(name);
        }
    }

    static int sum(int... nums) {
        int sum = 0;
        System.out.println("length : " + nums.length);

        for (int n : nums)
            sum += n;

        return sum;
    }


}
