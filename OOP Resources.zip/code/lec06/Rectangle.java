public class Rectangle{
	
	double length;
	double width;
	
	double calculateArea(){
		double area = length * width;
		return area;		
	}
	
	double calculatePerimeter(){
		return 2*(length + width);		
	}
	
}