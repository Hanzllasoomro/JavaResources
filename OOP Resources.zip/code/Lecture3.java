
import java.util.Scanner;

public class Lecture3 {
	
	public static void main(String args[]){
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter your name > ");
		String name = input.nextLine();
		System.out.println(name);	
		
		System.out.println("Enter a number > ");		
		int num = input.nextInt();
		System.out.println(num);
		
		System.out.println("Enter your height > ");
		double height = input.nextDouble();		
		System.out.println(height);
				
		
		
		

		
		
		
		/*		
		int age = 40;
		double height = 5.9;
		boolean status = true;			
		//System.out.printf("Age=%7d, Height=%-10.2f, Status=%b\n", age, height, status);
		//System.out.printf("Age=%7d, Height=%-10.2f, Status=%b\n", age, 2354.58, status);		
		//System.out.println("Age = " + age + " Height = " + height);				
		precendence order
		++, --
		()
		/ * %
		+ -		
		*/
		
		//int num = 10;		
		//System.out.println("sum = " + (num + 40));		
		
	}
	
}