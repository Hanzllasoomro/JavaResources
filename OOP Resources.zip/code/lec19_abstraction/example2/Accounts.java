package com.bitspedia.oop.lec19_abstraction.example2;

public class Accounts {
    Bank bank = new Bank();

    final private static int companyAccountNumber = 50;

    public void depositEarningsIntoAccount(Employee employee){
        if(employee.getBankAccountNumber() <=0 ) {
            System.out.println("Invalid Account");
            return;
        }
        bank.transferMoney(companyAccountNumber,
                employee.getBankAccountNumber(), employee.getEarnings());
    }
}

