package com.bitspedia.oop.lec18_inheritance;

public class Student extends Person {

    private String courseName;

    public Student(int id, String name, String courseName) {
        super(id, name);
        this.courseName = courseName;
        System.out.println("1 arg constructor of Student.");
    }

    public void m2(){
        System.out.println(getId());
        setId(20);
        System.out.println("m2 called in Student");
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
}
