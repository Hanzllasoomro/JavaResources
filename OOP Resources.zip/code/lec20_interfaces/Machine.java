package com.bitspedia.oop.lec20_interfaces;

public class Machine {
}
