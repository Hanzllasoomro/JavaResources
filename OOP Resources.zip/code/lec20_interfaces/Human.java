package com.bitspedia.oop.lec20_interfaces;

public class Human implements Walkable {

    @Override
    public void walk() {
        System.out.println("Define logic of walk for human... ");
    }
}
