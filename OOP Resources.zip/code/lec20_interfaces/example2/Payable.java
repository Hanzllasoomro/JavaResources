package com.bitspedia.oop.lec20_interfaces.example2;

public interface Payable {
    String companyName = "ABC CO.";

    double getPaymentAmount();

    default void m1(){
        System.out.println("m1 called...");
    }

}
