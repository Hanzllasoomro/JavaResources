package com.bitspedia.oop.lec16_arraylist;

public class MyInteger {

    private int value;

    public static int MAX_VALUE = 100;
    public static int MIN_VALUE = 1;

    public MyInteger(int n){
        if(n > 0 && n<=100)
            value = n;
    }

    public int getValue() {
        return value;
    }

    public static void main(String[] args) {
        MyInteger myInteger = new MyInteger(10);
        System.out.println(myInteger.getValue());
    }

}
