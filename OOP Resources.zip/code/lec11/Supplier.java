public class Supplier{
	
	int id;
	// other attrs of supplier
	
	Address postalAddress;

	// get and set methods ... 
	
}