package com.bitspedia.oop.lec19_polymorphism.example1;

public class Painter {
    int id;
    String name;

    final static int RATE = 200;

    public double estimatePaintingCost(Shape shape) {
        return shape.calculateArea() * RATE;
    }
}
