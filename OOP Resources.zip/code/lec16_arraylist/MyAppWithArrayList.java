package com.bitspedia.oop.lec16_arraylist;

import java.util.ArrayList;

public class MyAppWithArrayList {

    public static void main(String[] args) {

        ArrayList<String> names = new ArrayList<>();
        names.add("Abid");
        names.add("Zahid");
        names.add("Sajid");
        names.set(1, "Asif");

        String names1[] = names.toArray(new String[0]);

        if(names.isEmpty())
            System.out.println("the list is empty...");

        for(String name : names){
            System.out.println(name);
        }
        //names.remove(1);

//        for(String name : names){
//            System.out.println(name);
//        }
        System.out.println(names.size());

        names.ensureCapacity(200);



    }



}
