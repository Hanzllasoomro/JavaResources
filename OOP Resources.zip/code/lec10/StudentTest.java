public class StudentTest {
	
    public static void main(String[] args) {    
		Student std1 = new Student("Abid");			
		std1.display();
	}
}
