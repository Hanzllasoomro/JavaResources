public class TestApp {

	public static void main(String args[]){
		Rectangle rect = new Rectangle();
		rect.length = 3;
		rect.width = 4;
		
		System.out.println(rect.calculateArea());
		
		/*
		Student std = new Student();
		std.id = 1;
		std.name = "Hania";
		std.marks1 = 75;
		std.marks2 = 85;
		doSomething(std);
*/		
	}
	
	public static void doSomething(Student s){
		System.out.println(s.calculateAverage());
	}
	
}