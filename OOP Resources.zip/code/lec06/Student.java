public class Student {
	int id;
	String name;
	double marks1;
	double marks2;
	
	double calculateAverage(){
		double sum = marks1 + marks2;
		return sum / 2.0;
	}	
}