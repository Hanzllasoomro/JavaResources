package com.bitspedia.oop.lec21_exception_handling;

import java.util.InputMismatchException;
import java.util.Scanner;

public class SampleCode01 {

    public static void main(String args[]) {
        System.out.println("First statement.");

        Scanner scanner = new Scanner(System.in);
        int numbers[] = new int[]{1, 2, 7, 8};

        System.out.println("Enter value of index: ");
        try {
            int index = scanner.nextInt();
            System.out.println(numbers[index]);
            System.out.println("abc");
            System.out.println("xyz");
        } catch(InputMismatchException | ArrayIndexOutOfBoundsException exp){
            System.out.println("Exception triggered.");
            System.out.println(exp.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }

        System.out.println("Last statement.");
    }
}