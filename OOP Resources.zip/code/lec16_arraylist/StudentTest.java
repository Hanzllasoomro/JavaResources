package com.bitspedia.oop.lec16_arraylist;

public class StudentTest {

    public static void main(String[] args) {

        String name = args[0];
        String email = args[1];
        int age = Integer.parseInt(args[2]);
        double height = Double.parseDouble(args[3]);

        System.out.println(name);
        System.out.println(email);
        System.out.println(age);
        System.out.println(height);

    }
}
