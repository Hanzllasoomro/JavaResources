package com.bitspedia.oop.lec19_polymorphism;

public class Calculator {

    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        System.out.println(calculator.sum(5, 6));
        System.out.println(calculator.sum(5.0, 65.5));
    }

    double sum(int num1, int num2) {
        System.out.println("int called... ");
        return num1 + num2;
    }

    double sum(double num1, double num2) {
        System.out.println("double called ... ");
        return num1 + num2;
    }

}