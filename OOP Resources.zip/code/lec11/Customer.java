public class Customer{
	
	int id;
	
	// Other instance attributes of Customer comes here.
	// Skipped to focus on Address type.
	
	Address postalAddress;
	
	
}