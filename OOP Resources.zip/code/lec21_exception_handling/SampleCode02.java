package com.bitspedia.oop.lec21_exception_handling;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class SampleCode02 {

    public static void main(String args[]) throws IOException {
        writeOnFile("Welcome to Java Development ... ");
        System.out.println("Last statement of program.");
    }

    static void writeOnFile(String data) throws IOException {
        FileWriter fileWriter = null;
        fileWriter = new FileWriter("K:\\bitspedia.txt");
        PrintWriter printWriter = new PrintWriter(fileWriter);
        printWriter.write(data);
        printWriter.close();
    }
}