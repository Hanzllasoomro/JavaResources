package com.bitspedia.oop.lec19_abstraction.example1;

public abstract class Shape {
    int id;

    // declare - writing the prototype of the method (without body)
    public abstract double calculateArea();

    public String getColor(){
        return "Red";
    }

}
