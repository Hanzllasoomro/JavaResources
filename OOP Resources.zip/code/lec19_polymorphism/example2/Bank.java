package com.bitspedia.oop.lec19_polymorphism.example2;

public class Bank {

    public void transferMoney(int fromAccount, int toAccount, double amount){
        // ....
        System.out.println("Amount transferred.");
    }

}
