public class Package{
	
	int id;
	// products and other information ...
	
	Address sourceAddress;
	Address destinationAddress;
	
}