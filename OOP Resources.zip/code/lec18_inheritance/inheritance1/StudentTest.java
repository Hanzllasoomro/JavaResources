package com.bitspedia.oop.lec18_inheritance.inheritance1;

public class StudentTest {

    public static void main(String[] args) {

        Student student = new Student(1, "OOP");
        Student student2 = student; //new Student(1, "DB");

        if(student.equals(student2)) { // ==
            System.out.println("equal");
        } else {
            System.out.println("not equal");
        }
    }
}
