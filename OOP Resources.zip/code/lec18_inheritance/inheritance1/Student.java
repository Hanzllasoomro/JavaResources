package com.bitspedia.oop.lec18_inheritance.inheritance1;

public class Student extends Person {
    private String courseName;

    public Student(int id, String courseName) {
        super(id);
        this.courseName = courseName;
    }

//    @Override
//    public boolean equals(Object o) {
//        if (o == null)
//            return false;
//
//        if (o instanceof Student) {
//            Student s = (Student) o;
//            if (this.getId() == s.getId()) {
//                return true;
//            }
//        }
//        return false;
//    }

    public void m2() {
        System.out.println("m2 called ... ");
        m1();
    }
}